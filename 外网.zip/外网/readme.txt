花钱买了一个VPS，虚拟机，外国，服务器，CES 运行的linux，ubuntu18.04
选择的是virmach的
账号liuchangzheng25@163.com
密码VirMach-86
以后可以考虑
1、阿里云的香港服务器；
2、vultr.com/
3、https://app.cloudcone.com.cn/compute/create
后两个是外国的，可以按小时付费，有机器就收费，不开机也收，销毁机器才不收费

主机相关信息
Your IP is: 107.172.137.150 
Your Username is: root
Your Password is: wcwM2nPI10r8yL0Z9E

连接方式推荐cmder
超爽，ssh sftp都能用，效果比putty好
这两个方式都是鼠标右键为粘贴，输入密码时很方便

安装V2ray，使用的是脚本，v2ray-service.sh，压缩包中有
bbr tcp.sh
v2ray 用于翻墙，bbr加速

v2c是配置文件，端口为41184

ufw allow 41184 开通该端口防火墙

ufw status查询状态

参考文件
https://blog.verkey.org/209.html  v2ray+BBR牛的一逼！
https://tlanyan.me/v2ray-tutorial/?nsukey=Brsz6h7hEx0fE1V1fW46NW7bdkdcDs4TfVv3BO9nu3uKz0oTfOx7OCRMxW0v3a7Mny3mG3FaKg6xTof3nFcUrlS%2F5B5mX%2BlwbgFxJlFyFkXh%2Byc24Uduxm8jspUvgKA1sBvAC%2BgN97vC6ViV%2FYgmqw3sUUS5jq4B1qwJJCqim8j6ZH5LIAXUL7VNBU5VSpDi8%2Bbg2P%2ByzPXZ1XZhNLrFMg%3D%3D

v2ray 客户端varayn比较好用，

浏览器使用SwitchyOmega   proxy：socks5,127.0.0.1,10808
